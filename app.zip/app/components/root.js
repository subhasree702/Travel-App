import React from 'react'
import { SafeAreaView, StyleSheet, View } from 'react-native'
import { colors } from '../theme/colors'

const Root = ({ children, safeAreaViewStyle, viewStyle }) => {
    return (
        <SafeAreaView style={[styles.safeAreaView, safeAreaViewStyle]}>
            <View style={[styles.view, viewStyle]}>
                {children}
            </View>
        </SafeAreaView>
    )
}

export default Root;

const styles = StyleSheet.create({
    safeAreaView: {
        flex: 1,
        backgroundColor: colors.primary
    },
    view: {
        flex: 1,
        backgroundColor: colors.white
    }
})