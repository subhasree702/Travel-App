// import React from 'react';
// import { StyleSheet, Text, View, Image, ScrollView, TouchableOpacity } from 'react-native';
// import Header from './header';
// import { colors } from '../theme';
// import Assets from '../assets/images';
// import Icon from 'react-native-vector-icons/FontAwesome';
// import MaterialIcon from 'react-native-vector-icons/MaterialIcons';

// const MostVisited = () => {
//   const handleBookNow = () => {
//   };

//   return (
//     <View style={styles.container}>
//       <Header title="Most Visited" showBackButton={true} />
//       <ScrollView contentContainerStyle={styles.scrollViewContent}>
//         {mostVisitedPlaces.map((place, index) => (
//           <View key={index} style={styles.box}>
//             <Image source={place.image} style={styles.image} />
//             <View style={styles.detailsContainer}>
//               <Text style={styles.title}>{place.title}</Text>
//               <View style={styles.ratingLocationContainer}>
//                 <View style={styles.ratingContainer}>
//                   <Icon name="star" size={15} color={colors.primary} />
//                   <Text style={styles.ratingText}>{place.rating}</Text>
//                 </View>
//               </View>
//               <View style={styles.locationContainer}>
//                   <MaterialIcon
//                     name="location-on"
//                     size={18}
//                     color={colors.text}
//                   />
//                   <Text style={styles.location}>{place.location}</Text>
//                 </View>
//               <Text style={styles.price}>${place.price}</Text>
//               {/* <TouchableOpacity onPress={handleBookNow} style={styles.bookNowButton}>
//                 <Text style={styles.bookNowText}>Book Now</Text>
//               </TouchableOpacity> */}
//             </View>
//           </View>
//         ))}
//       </ScrollView>
//     </View>
//   );
// };

// const mostVisitedPlaces = [
//   {
//     title: 'Venice',
//     location: 'Italy',
//     price: 400,
//     image: Assets.mostvisited1,
//     rating: 4.8,
//   },
//   {
//     title: 'Sajek Valley',
//     location: 'Bangladesh',
//     price: 140,
//     image: Assets.mostvisited2,
//     rating: 4.9,
//   },
//   {
//     title: 'Kangchenjungha',
//     location: 'India',
//     price: 300,
//     image: Assets.mostvisited3,
//     rating: 4.7,
//   },
//   {
//     title: 'Saint Martin’s Island',
//     location: 'Cox’s Bazar',
//     price: 150,
//     image: Assets.mostvisited4,
//     rating: 4.6,
//   },
//   {
//     title: 'Lake Fond',
//     location: 'India',
//     price: 250,
//     image: Assets.mostvisited5,
//     rating: 4.2,
//   },
//   {
//     title: 'Tajhat Jamidarbari',
//     location: 'Bangladesh',
//     price: 120,
//     image: Assets.mostvisited6,
//     rating: 4.4,
//   },
// ];

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: colors.offWhite,
//   },
//   scrollViewContent: {
//     alignItems: 'center',
//   },
//   box: {
//     width: '90%',
//     backgroundColor: colors.white,
//     borderRadius: 15,
//     marginVertical: 8,
//     padding: 10,
//     flexDirection: 'row',
//     alignItems: 'center',
//   },
//   image: {
//     width: 100,
//     height: 100,
//     borderRadius: 10,
//     marginRight: 10,
//   },
//   detailsContainer: {
//     flex: 1,
//   },
//   ratingLocationContainer: {
//     flexDirection: 'row',
//     alignItems: 'center',
//     marginBottom: 5,
//   },
//   ratingContainer: {
//     flexDirection: 'row',
//     alignItems: 'center',
//     marginRight: 10,
//   },
//   ratingText: {
//     color: colors.black,
//     fontSize: 14,
//     marginLeft: 5,
//   },
//   title: {
//     color: colors.black,
//     fontWeight: 'bold',
//     fontSize: 18,
//     marginBottom: 5,
//   },
//   locationContainer: {
//     flexDirection: 'row',
//     alignItems: 'center',
//   },
//   location: {
//     color: colors.text,
//     fontWeight: '500',
//     fontSize: 16,
//   },
//   price: {
//     color: colors.black,
//     fontWeight: 'bold',
//     fontSize: 16,
//     marginBottom: 5,
//   },
//   bookNowButton: {
//     backgroundColor: colors.primary,
//     paddingVertical: 8,
//     paddingHorizontal: 12,
//     borderRadius: 5,
//     alignItems: 'center',
//     justifyContent: 'center',
//   },
//   bookNowText: {
//     color: colors.white,
//     fontWeight: 'bold',
//     fontSize: 16,
//   },
// });

// export default MostVisited;

import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import Header from './header';
import { colors } from '../theme';
import Assets from '../assets/images';
import Icon from 'react-native-vector-icons/FontAwesome';
import MaterialIcon from 'react-native-vector-icons/MaterialIcons';
import {useNavigation} from '@react-navigation/native';

const MostVisited = () => {
  const navigation = useNavigation();
  const handleBookNow = (place) => {
    console.log("Navigating to PlaceDetailsScreen with place:", place);
    navigation.navigate('PlaceDetailsScreen', { place }); 
  };
  

  return (
    <View style={styles.container}>
      <Header title="Most Visited" showBackButton={true} />
      <ScrollView contentContainerStyle={styles.scrollViewContent}>
        {mostVisitedPlaces.map((place, index) => (
          <View key={index} style={styles.box}>
            <Image source={place.image} style={styles.image} />
            <View style={styles.detailsContainer}>
              <Text style={styles.title}>{place.title}</Text>
              <View style={styles.ratingLocationContainer}>
                <View style={styles.ratingContainer}>
                  <Icon name="star" size={15} color={colors.primary} />
                  <Text style={styles.ratingText}>{place.rating}</Text>
                </View>
              </View>
              <View style={styles.locationContainer}>
                <MaterialIcon
                  name="location-on"
                  size={18}
                  color={colors.text}
                />
                <Text style={styles.location}>{place.location}</Text>
              </View>
              <Text style={styles.price}>${place.price}</Text>
              <TouchableOpacity
                onPress={() => handleBookNow(place)}
                style={styles.bookNowButton}>
                <Text style={styles.bookNowText}>Book Now</Text>
              </TouchableOpacity>
            </View>
          </View>
        ))}
      </ScrollView>
    </View>
  );
};

const mostVisitedPlaces = [
  {
    title: 'Venice',
    location: 'Italy',
    price: 400,
    image: Assets.mostvisited1,
    rating: 4.8,
  },
  {
    title: 'Sajek Valley',
    location: 'Bangladesh',
    price: 140,
    image: Assets.mostvisited2,
    rating: 4.9,
  },
  {
    title: 'Kangchenjungha',
    location: 'India',
    price: 300,
    image: Assets.mostvisited3,
    rating: 4.7,
  },
  {
    title: 'Saint Martin’s Island',
    location: 'Cox’s Bazar',
    price: 150,
    image: Assets.mostvisited4,
    rating: 4.6,
  },
  {
    title: 'Lake Fond',
    location: 'India',
    price: 250,
    image: Assets.mostvisited5,
    rating: 4.2,
  },
  {
    title: 'Tajhat Jamidarbari',
    location: 'Bangladesh',
    price: 120,
    image: Assets.mostvisited6,
    rating: 4.4,
  },
];

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.offWhite,
  },
  scrollViewContent: {
    alignItems: 'center',
  },
  box: {
    width: '90%',
    backgroundColor: colors.white,
    borderRadius: 15,
    marginVertical: 8,
    padding: 10,
    flexDirection: 'row',
    alignItems: 'center',
  },
  image: {
    width: 100,
    height: 100,
    borderRadius: 10,
    marginRight: 10,
  },
  detailsContainer: {
    flex: 1,
  },
  ratingLocationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 5,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 10,
  },
  ratingText: {
    color: colors.black,
    fontSize: 14,
    marginLeft: 5,
  },
  title: {
    color: colors.black,
    fontWeight: 'bold',
    fontSize: 18,
    marginBottom: 5,
  },
  locationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  location: {
    color: colors.text,
    fontWeight: '500',
    fontSize: 16,
  },
  price: {
    color: colors.black,
    fontWeight: 'bold',
    fontSize: 16,
    marginBottom: 5,
  },
  bookNowButton: {
    backgroundColor: colors.primary,
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 13,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bookNowText: {
    color: colors.white,
    fontWeight: 'bold',
    fontSize: 16,
  },
});

export default MostVisited;
