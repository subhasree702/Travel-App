import React from 'react';
import {View, FlatList, StyleSheet, Text, Image} from 'react-native';
import Header from './header';
import { colors } from '../theme';
import Assets from '../assets/images';


const Services = () => {
  const originalData = [
    {title: 'Emergency Contacts', image: Assets.contact},
    {title: 'Currency Converter', image: Assets.currency},
    {title: 'Emergency Assistant', image: Assets.emergency},
    {title: 'Exchange Currency', image: Assets.Exchange},
    {title: 'Language Translator', image: Assets.Language},
    {title: 'Offline Maps', image: Assets.Offline},
    {title: 'Weather Forecast', image: Assets.Weather},
  ];

  const renderItem = ({item}) => (
    <View style={styles.box}>
      <Image source={item.image} style={styles.image} />
      <Text style={styles.Text}>{item.title}</Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <Header title="Extra Services" showBackButton={true} />
      <View
        style={{marginTop: 30, justifyContent: 'center', alignItems: 'center'}}>
        <FlatList
          data={originalData}
          renderItem={renderItem}
          keyExtractor={(item, index) => `${item.title}_${index}`}
          numColumns={2}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  box: {
    margin: 5,
    padding: 30,
    backgroundColor: colors.white,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
  },
  image: {
    marginBottom: 5,
  },
  Text: {
    color: colors.black,
    fontWeight: 'bold',
  },
});

export default Services;
