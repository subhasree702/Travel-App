import React from 'react';
import {View, FlatList, StyleSheet, Text, Image} from 'react-native';
import Header from './header';
import { colors } from '../theme';
import Assets from '../assets/images';

const Categories = () => {
  const originalData = [
    {title: 'Mountains', image: Assets.mountain},
    {title: 'Beach', image: Assets.beach},
    {title: 'Lakes', image: Assets.lake},
    {title: 'Camp', image: Assets.camp},
  ];

  const repeatedData = Array.from({length: 5}, () => originalData).flat();

  const renderItem = ({item}) => (
    <View style={styles.box}>
      <Image source={item.image} style={styles.image} />
      <Text>{item.title}</Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <Header title="Categories" showBackButton={true} />
      <View
        style={{marginTop: 40}}>
        <FlatList
          data={repeatedData}
          renderItem={renderItem}
          keyExtractor={(item, index) => `${item.title}_${index}`}
          numColumns={4}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  box: {
    flex: 1,
    margin: 5,
    padding: 10,
    backgroundColor: colors.white,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
    marginTop: 20,
  },
  image: {
    width: 40,
    height: 40,
    marginBottom: 5,
  },
});

export default Categories;
