import React from 'react'
import { ActivityIndicator, StyleSheet, Text, TouchableOpacity } from 'react-native'
import { colors, fontSize, hp, wp } from '../theme'

const Button = ({ title, onPress, buttonStyle, buttonTextStyle, loading }) => {
    return (
        <TouchableOpacity disabled={loading} activeOpacity={0.9} style={[styles.button, buttonStyle]} onPress={onPress}>
            {loading ? (
                <ActivityIndicator size={'small'} color={colors.white} />
            ) : (
                <Text style={[styles.buttonText, buttonTextStyle]}>{title}</Text>
            )}
        </TouchableOpacity>
    )
}

export default Button

const styles = StyleSheet.create({
    button: {
        width: '100%',
        backgroundColor: colors.primary,
        borderRadius: wp(2),
        alignItems: 'center',
        paddingVertical: hp(1.5)
    },
    buttonText: {
        color: colors.white,
        fontSize: fontSize.fontSize18,
    },
})