import React from "react";
import {View, Text, StyleSheet, Image, TextInput} from 'react-native';
import { colors } from '../theme/colors';
import { TouchableOpacity } from "react-native-gesture-handler";
import {useNavigation} from '@react-navigation/native';
import Assets from "../assets/images";
import LottieView from 'lottie-react-native';
const BeginComponent =()=>{
    const navigation = useNavigation();
    const handelnavigation =()=>{
        navigation.navigate('HomeScreen');
    }
    return(
        <View style={styles.container}>
          <View style={styles.imageContainer}>
            {/* <Image source={Assets.Congo} style={styles.image}/> */}
            <LottieView source={require('../assets/images/Animation.json')} autoPlay loop 
            speed={0.5}
            style={styles.lottie}
            />
          </View>
          <View style={styles.textholder}>
            <Text style={styles.input}>You’re all set!</Text>
          </View>
          <View style={styles.textholder}>
            <TouchableOpacity style={styles.buttontext} onPress={handelnavigation}>
                <Text style={styles.button}>Let’s Begin</Text>
            </TouchableOpacity>
          </View>
        </View>
    )
}
const styles = StyleSheet.create({
container: {
    flex: 1,
    backgroundColor: colors.offWhite,
  },
  imageContainer: {
    flex:0.6,
    justifyContent: 'flex-end',
    alignItems: 'center',
    padding: 20,
  },
  image: {
    borderRadius: 20,
    resizeMode: 'contain',
  },
  textholder:{
    justifyContent: 'flex-end',
    alignItems: 'center',
    padding: 20,
  },
  input:{
    fontSize:23,
    color:colors.black,
    fontWeight:"bold"
  },
  button:{
    fontSize:15,
    color:colors.white,
  },
  buttontext:{
    backgroundColor: colors.primary,
    padding: 15,
    borderRadius: 25,
    alignItems: 'center',

  },
  lottie: {
    width: 300,
    height: 250,
},
});
export default BeginComponent ;

