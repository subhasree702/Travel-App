import React from 'react';
import { StyleSheet, TouchableOpacity } from 'react-native';
import { Text, View } from 'react-native';
import { colors } from '../theme/colors';
import { useNavigation } from '@react-navigation/native';

const ListHeader = ({ title, text }) => {
  const navigation = useNavigation();

  const handleTextPress = () => {
    switch (title) {
      case 'Categories':
        navigation.navigate('Categories');
        break;
      case 'Most Visited':
        navigation.navigate('MostVisited');
        break;
        case 'Services':
          navigation.navigate('Services');
          break;
      default:
        break;
    }
  };

  return (
    
      <View style={styles.container}>
        <Text style={styles.title}>{title}</Text>
        <TouchableOpacity onPress={handleTextPress}>
        <Text style={styles.text}>{text}</Text>
        </TouchableOpacity>
      </View>
   
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 10,
    marginTop: 10,
  },
  title: {
    color: colors.black,
    fontWeight: 'bold',
    fontSize: 20,
  },
  text: {
    color: colors.primary,
    fontSize: 15,
    marginTop: 6,
  },
});

export default ListHeader;
