import React, { useState } from 'react'
import { StyleSheet, Text, View, TextInput } from 'react-native'
import { colors, fontFamily, fontSize, hp, wp } from '../theme';

const Input = (props) => {
    const { title, titleStyle, inputStyle, inputContainerStyle, error, errorStyle } = props;
    const [isFocused, setIsFocused] = useState(false)

    const onFocus = () => {
        setIsFocused(true)
    }

    const onBlur = () => {
        setIsFocused(false)
    }

    return (
        <View style={[styles.inputContainer, inputContainerStyle]}>
            {title ? <Text style={[styles.title, { color: isFocused ? colors.primary : colors.black }, titleStyle]}>{title}</Text> : null}
            <TextInput
                {...props}
                style={[styles.input, { borderColor: isFocused ? colors.primary : colors.gray }, inputStyle]}
                onFocus={onFocus}
                onBlur={onBlur}
                selectionColor={colors.primary}
                placeholder={props.placeholder || title || ''}
                placeholderTextColor={colors.gray}
            />
            {error && <Text style={[styles.error, errorStyle]}>{error}</Text>}
        </View>
    )
}

export default Input

const styles = StyleSheet.create({
    inputContainer: {

    },
    title: {
        fontFamily: fontFamily.medium,
        color: colors.primary,
        marginBottom: hp(0.5)
    },
    input: {
        borderWidth: 1,
        borderRadius: wp(2),
        paddingHorizontal: wp(2),
        color: colors.black
    },
    error: {
        color: colors.error,
        fontSize: fontSize.fontSize12,
        fontFamily: fontFamily.regular,
        marginTop: hp(0.5)
    }
})