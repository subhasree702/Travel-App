import { Dimensions, PixelRatio } from "react-native";

const { height, width } = Dimensions.get('window');

const metrics = {
    screenWidth: width < height ? width : height,
    screenHeight: width < height ? height : width
}

const wp = (percent) => {
    return PixelRatio.roundToNearestPixel(width * percent / 100);
};

const hp = (percent) => {
    return PixelRatio.roundToNearestPixel(height * percent / 100);
};

export { metrics, wp, hp }