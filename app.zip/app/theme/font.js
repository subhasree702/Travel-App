const fontSize = {
    fontSize10: 10,
    fontSize12: 12,
    fontSize14: 14,
    fontSize16: 16,
    fontSize18: 18,
    fontSize20: 20,
    fontSize22: 22,
    fontSize24: 24
}

const fontFamily = {
    regular: 'Roboto-Regular',
    medium: 'Roboto-Medium',
    bold: 'Roboto-Bold',
    light: 'Roboto-Light'
}

export { fontSize, fontFamily }