import { colors } from "./colors";
import { fontFamily, fontSize } from "./font";
import { metrics, wp, hp } from "./metrics";

export {
    colors,
    fontFamily,
    fontSize,
    metrics,
    wp,
    hp
}