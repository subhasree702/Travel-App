export const colors = {
    text: 'gray',
    error: 'red',
    black: 'black',
    white: 'white',
    blue:"#0000ff",
    powderblue :"#b0e0e6",
    primary:"#E1341E",
    secondary:'#1ECBE1',
    offWhite: '#f6f6f6',

    gray:"#808080"
  };
  