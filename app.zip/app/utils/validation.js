import * as yup from 'yup';

export const loginSchema =  yup.string().required("Please enter phone number.").min(10, "Please enter valid phone number.").max(10, "Please enter valid phone number.")

export const RegistrationSchema= yup.object
({
   FirstName:'' ,
   LastName:'',
   Address:'',
   Apartment:'',
   City:'',
   Postslcode:''
})