import { StyleSheet } from "react-native";
import { wp } from "../theme";

export const commonStyle = StyleSheet.create({
    flexCenter: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center'
    },
    row: {
        flexDirection: 'row',
        alignItems: 'center'
    },
    rowCenter: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center'
    },
    rowSpaceBetween: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between'
    },
    rowP4: {
        flexDirection: 'row',
        alignItems: 'center',
        padding: wp(4)
    },
    rowCenterP4: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        padding: wp(4)
    },
    rowSpaceBetweenP4: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: wp(4)
    },
    logo: {
        width: wp(60),
        aspectRatio: 4.5 / 1
    }
})