export const EDColors = {
    text: 'gray',
    error: 'red',
    black: 'black',
    white: 'white',
    blue:"#0000ff",
    powderblue :"#b0e0e6",
    primary:"#F75D37"
  };
  