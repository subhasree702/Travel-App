import React, { useState } from 'react';
import { Alert, Image, ImageBackground, Keyboard, StyleSheet, View } from 'react-native';
import auth from '@react-native-firebase/auth';
import { colors } from '../../theme/colors';
import { Button, Root, Input } from '../../components';
import { hp, wp } from '../../theme';
import { loginSchema } from '../../utils/validation';
import Assets from '../../assets/images';
import { commonStyle } from '../../utils/commonStyles';

const countryCode = '+91'

const Login = ({ navigation }) => {
  const [phoneNumber, setPhoneNumber] = useState("")
  const [phoneNumberError, setPhoneNumberError] = useState("")
  const [loading, setLoading] = useState(false)

  const handleGetOtp = async () => {
    Keyboard.dismiss()
    setLoading(true)
    try {
      const confirmation = await auth().signInWithPhoneNumber(`${countryCode}${phoneNumber}`);
      setLoading(false)
      navigation.navigate("VerifyOtp", { phoneNumber, confirmation })
    } catch (error) {
      setLoading(false)
      Alert.alert("Unable to send otp, please try again.")
    }
  }

  const handleTextChange = (value) => {
    setPhoneNumber(value)
    setPhoneNumberError("")
  }

  return (
    <Root>
      <View style={styles.container}>
        <View style={commonStyle.flexCenter} >
          <Image
            style={commonStyle.logo}
            source={Assets.logo}
            resizeMode='contain'
          />
        </View>
        <ImageBackground
          style={styles.wave}
          source={Assets.wave}
          resizeMode='cover'
        >
          <Input
            title="Phone number"
            onChangeText={handleTextChange}
            maxLength={10}
            keyboardType='number-pad'
            error={phoneNumberError}
          />
          <Button
            title="Get OTP"
            onPress={handleGetOtp}
            loading={loading}
            buttonStyle={{ marginTop: hp(2) }}
          />
        </ImageBackground>
      </View>
    </Root>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.primary
  },
  wave: {
    width: wp(100),
    height: wp(100),
    justifyContent: 'center',
    paddingHorizontal: wp(4)
  }
})

export default Login;