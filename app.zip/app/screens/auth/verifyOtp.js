import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    TouchableOpacity,
    StyleSheet,
    Alert,
    ImageBackground,
} from 'react-native';
import OTPInputView from '@twotalltotems/react-native-otp-input'
import { colors, fontFamily, fontSize, hp, wp } from '../../theme';
import auth from '@react-native-firebase/auth';
import { Button, Root } from '../../components';
import { commonStyle } from '../../utils/commonStyles';
import { Image } from 'react-native';
import Assets from '../../assets/images';

const countryCode = "+91"
const pinCount = 6
const resetTime = 60

const VerifyOtp = ({ navigation, route }) => {
    const { phoneNumber, confirmation } = route.params;

    const [confirm, setConfirm] = useState(confirmation)
    const [count, setCount] = useState(resetTime);
    const [code, setCode] = useState("")
    const [loading, setLoading] = useState(false)

    useEffect(() => {
        let timer = setInterval(() => {
            if (count == 0) {
                clearInterval(timer)
            }
            else {
                setCount(count - 1)
            }
        }, 1000)
        return () => clearInterval(timer)
    }, [count])

    useEffect(() => {
        const subscriber = auth().onAuthStateChanged(onAuthStateChanged);
        return subscriber;
    }, []);

    const onAuthStateChanged = (user) => {
        if (user) {
            // setLoading(false)
            // navigation.navigate("AppNavigation")
        }
    }

    const confirmCode = async () => {
        setLoading(true)
        try {
            const response = await confirm.confirm(code)
            if (response) {
                setLoading(false)
                navigation.navigate("Registration")
            } else {
                setLoading(false)
                Alert.alert("Unable to verify otp, please try again.")
            }
        } catch (error) {
            setLoading(false)
            Alert.alert("Unable to verify otp, please try again.")
        }
    }

    const resendOtp = async () => {
        const confirmation = await auth().signInWithPhoneNumber(`${countryCode}${phoneNumber}`);
        setConfirm(confirmation);
        setCount(resetTime)
    }

    return (
        <Root>
            <View style={styles.container}>
                <View style={commonStyle.flexCenter} >
                    <Image
                        style={commonStyle.logo}
                        source={Assets.logo}
                        resizeMode='contain'
                    />
                </View>
                <ImageBackground
                    style={styles.wave}
                    source={Assets.wave}
                    resizeMode='cover'
                >
                    <OTPInputView
                        style={styles.otpInput}
                        pinCount={pinCount}
                        autoFocusOnLoad
                        codeInputFieldStyle={styles.codeInputFieldStyle}
                        codeInputHighlightStyle={styles.codeInputHighlightStyle}
                        onCodeFilled={setCode}
                    />
                    <Button
                        title={'Verify'}
                        onPress={confirmCode}
                        loading={loading}
                        buttonStyle={{ marginVertical: hp(2) }}
                    />
                    <View style={commonStyle.rowCenter}>
                        {count == 0 ? (
                            <TouchableOpacity
                                activeOpacity={0.9}
                                onPress={resendOtp}
                            >
                                <Text style={styles.resendText}>Resend OTP</Text>
                            </TouchableOpacity>
                        ) : (
                            <View style={commonStyle.rowCenter}>
                                <Text style={{ color: '#000' }}>Resend OTP in : </Text>
                                <Text style={styles.resendText}>{`${count} seconds`}</Text>
                            </View>
                        )}
                    </View>
                </ImageBackground>
            </View>
        </Root>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.primary
    },
    resendText: {
        fontFamily: fontFamily.medium,
        color: colors.primary,
        fontSize: fontSize.fontSize14
    },
    otpInput: {
        width: wp(92),
        height: wp(15)
    },
    codeInputFieldStyle: {
        height: wp(12),
        width: wp(12),
        color: colors.black,
        borderColor: colors.gray
    },
    codeInputHighlightStyle: {
        borderColor: colors.primary,
        borderWidth: 2
    },
    wave: {
        width: wp(100),
        height: wp(100),
        justifyContent: 'center',
        paddingHorizontal: wp(4)
    }
});

export default VerifyOtp;