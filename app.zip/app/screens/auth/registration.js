import React, {useState} from 'react';
import {StyleSheet, Text, View, Image, ScrollView} from 'react-native';
import {colors} from '../../theme';
import {hp, wp} from '../../theme';
import Assets from '../../assets/images';
import {Input, Root, Button} from '../../components';

const Registration = ({navigation}) => {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [address, setAddress] = useState('');
  const [apartment, setApartment] = useState('');
  const [city, setCity] = useState('');
  const [postalCode, setPostalCode] = useState('');
  const [errors, setErrors] = useState({});

  const handleSubmit = () => {
    const errors = {};
    if (!firstName.trim()) {
      errors.firstName = 'First name is required';
    }
    if (!lastName.trim()) {
      errors.lastName = 'Last name is required';
    }
    if (!address.trim()) {
      errors.address = 'Address is required';
    }
    if (!apartment.trim()) {
      errors.apartment = 'Apartment is required';
    }
    if (!city.trim()) {
      errors.city = 'City is required';
    }
    if (!postalCode.trim()) {
      errors.postalCode = 'Postal code is required';
    }
    setErrors(errors);

    if (Object.keys(errors).length === 0) {
      console.log('Form submitted successfully');
      navigation.navigate('BeginComponent');
    } else {
      setTimeout(() => {
        setErrors({});
      }, 3000);
    }
  };

  return (
    <Root>
      <ScrollView contentContainerStyle={styles.scrollView}>
        <View style={styles.container}>
          <Image
            source={Assets.Registration}
            style={{width: wp(92), height: wp(92)}}
          />
          <View style={{width: wp(92)}}>
            <Input
              title="First Name"
              value={firstName}
              onChangeText={setFirstName}
            />
            {errors.firstName && (
              <Text style={styles.error}>{errors.firstName}</Text>
            )}
            <Input
              title="Last Name"
              value={lastName}
              onChangeText={setLastName}
            />
            {errors.lastName && (
              <Text style={styles.error}>{errors.lastName}</Text>
            )}
            <Input title="Address" value={address} onChangeText={setAddress} />
            {errors.address && (
              <Text style={styles.error}>{errors.address}</Text>
            )}
            <Input
              title="Apartment, suite, etc."
              value={apartment}
              onChangeText={setApartment}
            />
            {errors.apartment && (
              <Text style={styles.error}>{errors.apartment}</Text>
            )}
          </View>
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              width: wp(92),
            }}>
            <View style={{width: '48%'}}>
              <Input title="City" value={city} onChangeText={setCity} />
              {errors.city && <Text style={styles.error}>{errors.city}</Text>}
            </View>
            <View style={{width: '48%'}}>
              <Input
                title="Postal code"
                value={postalCode}
                onChangeText={setPostalCode}
              />
              {errors.postalCode && (
                <Text style={styles.error}>{errors.postalCode}</Text>
              )}
            </View>
          </View>

          <View style={{marginTop: hp(1), width: wp(92)}}>
            <Button title="Submit" onPress={handleSubmit} />
          </View>
        </View>
      </ScrollView>
    </Root>
  );
};

const styles = StyleSheet.create({
  scrollView: {
    flexGrow: 1,
  },
  container: {
    flexGrow: 1,
    backgroundColor: colors.white,
    padding: wp(4),
    alignItems: 'center',
  },
  error: {
    color: 'red',
    marginTop: hp(0.5),
  },
});

export default Registration;
