import React, { useEffect } from 'react'
import { StyleSheet, View, Image } from 'react-native'
import { Root } from '../components'
import { colors, wp } from '../theme'
import Assets from '../assets/images'

const Splash = ({ navigation }) => {

    useEffect(() => {
        setTimeout(() => {
            navigation.navigate("Onboarding")
        }, 2000);
    }, [])


    return (
        <Root>
            <View style={styles.container}>
                <Image
                    source={Assets.logo}
                    style={styles.image}
                    resizeMode="contain"
                />
            </View>
        </Root>
    )
}

export default Splash

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.primary,
        justifyContent: 'center',
        alignItems: 'center',
    },
    image: {
        width: wp(50),
        height: wp(50)
    }
})