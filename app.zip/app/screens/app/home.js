import React from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  StyleSheet,
  Image,
  TextInput,
  ImageBackground,
  StatusBar,
} from 'react-native';
import Assets from '../../assets/images';
import { colors } from '../../theme';
import Icon from 'react-native-vector-icons/FontAwesome';
import ListHeader from '../../components/listHeader';

const HomeScreen = () => {
  return (
    <ImageBackground source={Assets.Background} style={styles.backgroundImage}>
      <StatusBar hidden={true} />
      <View style={styles.image}>
        <Image source={Assets.Applogo} />
      </View>
      <View style={styles.container}>
        <View style={styles.searchContainer}>
          <TextInput
            style={styles.searchInput}
            placeholder="Search any places..."
            placeholderTextColor={colors.gray}
          />
        </View>
        <ListHeader title="Categories" text="See All" />
        <View style={styles.box}>
          <View style={styles.buttonWrapper}>
            <TouchableOpacity style={styles.button}>
              <Image source={Assets.mountain} style={styles.buttonImage} />
              <Text style={{marginTop: 10}}>Mountains</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.buttonWrapper}>
            <TouchableOpacity style={styles.button}>
              <Image source={Assets.beach} style={styles.buttonImage} />
              <Text style={{marginTop: 10}}>Beach</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.buttonWrapper}>
            <TouchableOpacity style={styles.button}>
              <Image source={Assets.lake} style={styles.buttonImage} />
              <Text style={{marginTop: 10}}>Lakes</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.buttonWrapper}>
            <TouchableOpacity style={styles.button}>
              <Image source={Assets.camp} style={styles.buttonImage} />
              <Text style={{marginTop: 10}}>Camp</Text>
            </TouchableOpacity>
          </View>
        </View>
        <ListHeader title="Most Visited" text="See All" />
        <View style={styles.box}>
          <View>
            <Image source={Assets.mostvisited} style={styles.smallimage} />
            <View style={styles.overlay}>
              <Icon name="star" size={13} color={colors.white} />
              <Text style={styles.ratingText}>4.5</Text>
            </View>
            <Text style={styles.textInsideImage}>Kanchenjungha</Text>
            <Text style={styles.textInsideImage2}>Rangpur, Bangladesh</Text>
          </View>
          <View>
            <Image source={Assets.mostvisitedplace} style={styles.smallimage} />
            <View style={styles.overlay}>
              <Icon name="star" size={13} color={colors.white} />
              <Text style={styles.ratingText}>4.5</Text>
            </View>
            <Text style={styles.textInsideImage}>Cox’s Bazar Sea Beach</Text>
            <Text style={styles.textInsideImage2}>Cox’s Bazar, Bangladesh</Text>
          </View>
        </View>
        <ListHeader title="Services" text="See All" />
        <View style={styles.box}></View>
        <View style={styles.smallBoxesContainer}>
          <View style={styles.smallBox1}>
            <View style={styles.aligntext}>
              <Image source={Assets.hotel} style={{height: 10, width: 10}} />
              <Text style={styles.text}>Hotel</Text>
            </View>
          </View>
          <View style={styles.smallBox}>
            <View style={styles.aligntext}>
              <Image source={Assets.flight} style={{height: 10, width: 10}} />
              <Text style={styles.text2}>Flight</Text>
            </View>
          </View>
          <View style={styles.smallBox}>
            <View style={styles.aligntext}>
              <Image source={Assets.bus} style={{height: 10, width: 10}} />
              <Text style={styles.text2}>Bus</Text>
            </View>
          </View>
          <View style={styles.smallBox}>
            <View style={styles.aligntext}>
              <Image source={Assets.boat} style={{height: 10, width: 10}} />
              <Text style={styles.text2}>Boat</Text>
            </View>
          </View>
        </View>
      </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  backgroundImage: {
    flex: 1,
    justifyContent: 'center',
    height: '25%',
  },
  image: {
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 90,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 30,
    paddingHorizontal: 20,
  },
  searchInput: {
    flex: 1,
    backgroundColor: colors.white,
    borderRadius: 10,
    paddingHorizontal: 15,
    paddingVertical: 10,
    fontSize: 16,
  },
  box: {
    flexDirection: 'row',
    justifyContent: 'space-evenly',
    marginTop: 10,
    padding: 10,
  },
  buttonWrapper: {
    backgroundColor: colors.white,
    borderRadius: 10,
    height: '120%',
    width: '23%',
  },
  button: {
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 20,
  },
  smallimage: {
    height: 160,
    width: 180,
    borderRadius: 20,
  },
  textInsideImage: {
    position: 'absolute',
    bottom: 20,
    left: 10,
    color: 'white',
    fontSize: 14,
  },
  textInsideImage2: {
    position: 'absolute',
    bottom: 10,
    left: 10,
    color: 'white',
    fontSize: 9,
  },
  overlay: {
    position: 'absolute',
    top: 10,
    left: 10,
    flexDirection: 'row',
    alignItems: 'center',
  },
  ratingText: {
    marginLeft: 5,
    color: colors.white,
    fontSize: 13,
    fontWeight: 'bold',
  },
  smallBoxesContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 10,
  },
  smallBox: {
    backgroundColor: colors.white,
    borderRadius: 10,
    width: '23%',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 10,
  },
  smallBox1: {
    backgroundColor: colors.primary,
    borderRadius: 10,
    width: '23%',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 10,
  },
  aligntext: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  text: {
    paddingHorizontal: 5,
    color: colors.white,
  },
  text2: {
    paddingHorizontal: 7,
    color: colors.black,
  },
});
export default HomeScreen;
