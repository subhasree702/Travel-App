import React, { useRef, useState } from 'react';
import { Text, View, Image, StyleSheet, TouchableOpacity, FlatList } from 'react-native';
import Assets from '../assets/images';
import { Root } from '../components';
import { colors, fontFamily, fontSize, hp, wp } from '../theme';
import { commonStyle } from '../utils/commonStyles';

const Onboarding = ({ navigation }) => {
  const [currentItemIndex, setCurrentItemIndex] = useState(0);

  const flatListRef = useRef(null)

  const handleNext = () => {
    if (currentItemIndex == data?.length - 1) {
      navigation.navigate("Auth")
    }
    else {
      let nextItemIndex = currentItemIndex + 1
      setCurrentItemIndex(nextItemIndex);
      flatListRef?.current?.scrollToIndex({ index: nextItemIndex, animated: true });
    }
  };

  const renderItem = ({ item, index }) => {
    return (
      <View style={{ width: wp(100), padding: wp(4) }}>
        <Image source={item.image} style={styles.image} />
        <View style={{ marginTop: hp(2) }}>
          <Text style={styles.title}>{item.title}</Text>
          <Text style={styles.caption}>{item.caption}</Text>
        </View>
      </View>
    )
  }

  const onScrollToIndexFailed = () => {

  }

  const viewabilityConfig = { itemVisiblePercentThreshold: 100 }

  const onViewableItemsChanged = React.useCallback(({ viewableItems }) => {
    if (viewableItems && viewableItems?.length > 0) {
      setCurrentItemIndex(viewableItems[0]?.index)
    }
  }, [])

  return (
    <Root>
      <View style={styles.container}>
        <View style={{ flex: 1 }}>
          <FlatList
            ref={flatListRef}
            data={data}
            renderItem={renderItem}
            pagingEnabled={true}
            horizontal={true}
            showsHorizontalScrollIndicator={false}
            keyExtractor={(item) => `${item?.id}`}
            onScrollToIndexFailed={onScrollToIndexFailed}
            viewabilityConfig={viewabilityConfig}
            onViewableItemsChanged={onViewableItemsChanged}
          />
        </View>
        <View style={commonStyle.rowSpaceBetweenP4}>
          <View style={commonStyle.rowCenter}>
            {data.map((item, index) => (
              <View
                key={item.id}
                style={{
                  ...styles.dot,
                  backgroundColor: index === currentItemIndex ? colors.primary : colors.text
                }}
              />
            ))}
          </View>

          <TouchableOpacity
            activeOpacity={0.9}
            style={styles.nextButton}
            onPress={handleNext}
          >
            <Text style={styles.buttonText}>{currentItemIndex == data?.length - 1 ? "Let's go" : "Next"}</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Root>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
  image: {
    width: wp(92),
    height: wp(92),
    resizeMode: 'contain'
  },
  nextButton: {
    backgroundColor: colors.primary,
    paddingVertical: hp(1.5),
    paddingHorizontal: wp(8),
    borderRadius: wp(4)
  },
  buttonText: {
    fontFamily: fontFamily.medium,
    fontSize: fontSize.fontSize16,
    color: colors.white
  },
  title: {
    fontSize: fontSize.fontSize24,
    fontFamily: fontFamily.bold,
    color: colors.black,
    textAlign: 'center',
  },
  caption: {
    textAlign: 'center',
    fontSize: fontSize.fontSize14,
    fontFamily: fontFamily.regular,
    marginTop: hp(1),
    color: colors.black,
  },
  dot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginHorizontal: 5
  }
});

export default Onboarding;

const data = [
  { id: '1', image: Assets.onboarding1, title: 'Explore The World With TourPlace', caption: 'Lorem ipsum dolor sit amet consectetur. Mi ultricies ultrices fermentum a. Duis neque lectus pharetra ac sed lorem.' },
  { id: '2', image: Assets.onboarding2, title: 'Make Memories That Last a Lifetime', caption: 'Lorem ipsum dolor sit amet consectetur. Mi ultricies ultrices fermentum a. Duis neque lectus pharetra ac sed lorem.' },
  { id: '3', image: Assets.onboarding3, title: 'Make Memories That Last a Lifetime', caption: 'Lorem ipsum dolor sit amet consectetur. Mi ultricies ultrices fermentum a. Duis neque lectus pharetra ac sed lorem.' },
];

