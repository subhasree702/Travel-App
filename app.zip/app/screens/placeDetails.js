import React from 'react';
import { StyleSheet, View, Text, StatusBar, ImageBackground, TouchableOpacity } from 'react-native';
import { colors, hp, wp } from '../theme';
import Header from '../components/header';
import FontAwesome from 'react-native-vector-icons/FontAwesome';

const PlaceDetailsScreen = ({ route }) => {
  const { place } = route.params;
  //console.log('Received place in PlaceDetailsScreen:', place);

  return (
    <View style={styles.container}>
      <StatusBar hidden />
      <ImageBackground source={place.image} style={styles.image}>
        <Header title="Place Details" />
      </ImageBackground>
      <View style={styles.detailsContainer}>
        <View style={{ flexDirection: 'column' }}>
          <Text style={styles.title}>{place.title}</Text>
          <Text style={styles.location}>{place.location}</Text>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <FontAwesome name="star" size={20} color={colors.primary} style={{ marginRight: 5 }} />
            <Text style={styles.rating}>{place.rating}</Text>
            <Text>{"  (150 Reviews)"}</Text>
          </View>
        </View>
        <Text style={styles.price}>${place.price}</Text>
      </View>
      <View style={styles.section}>
        <Text style={styles.header}>About</Text>
        <Text>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Arcu, arcu dictumst habitant vel ut et pellentesque. Ut in egestas blandit netus in scelerisque. Eget lectus ultrices pellentesque id.</Text>
      </View>
      <View style={styles.section}>
        <Text style={styles.header}>Facilities</Text>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <FontAwesome name="check" size={16} color={colors.black} style={{ marginRight: 5 }} />
          <Text style={styles.facility}>Free WIFI</Text>
        </View>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <FontAwesome name="check" size={16} color={colors.black} style={{ marginRight: 5 }} />
          <Text style={styles.facility}>Pool</Text>
        </View>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <FontAwesome name="check" size={16} color={colors.black} style={{ marginRight: 5 }} />
          <Text style={styles.facility}>Breakfast</Text>
        </View>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <FontAwesome name="check" size={16} color={colors.black} style={{ marginRight: 5 }} />
          <Text style={styles.facility}>Lunch</Text>
        </View>
      </View>
      <TouchableOpacity style={styles.bookNowButton}>
        <Text style={styles.bookNowText}>Book Now</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.offWhite,
  },
  image: {
    width: wp(103),
    height: wp(85),
    resizeMode: 'cover',
  },
  detailsContainer: {
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 20,
  },
  title: {
    color: colors.black,
    fontWeight: 'bold',
    fontSize: 24,
  },
  location: {
    color: colors.text,
    fontSize: 18,
  },
  price: {
    color: colors.black,
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 50,
  },
  rating: {
    color: colors.black,
    fontSize: 18,
  },
  section: {
    padding: 20,
  },
  header: {
    color: colors.black,
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  facility: {
    color: colors.black,
    fontSize: 16,
    marginLeft: 5,
  },
  bookNowButton: {
    backgroundColor: colors.primary,
    borderRadius: 25,
    paddingVertical: 15,
    alignItems: 'center',
    marginHorizontal: 20,
    marginTop: 20,
  },
  bookNowText: {
    color: colors.white,
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default PlaceDetailsScreen;

