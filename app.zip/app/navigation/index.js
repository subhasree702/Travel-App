import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

import Splash from '../screens/splash';
import Onboarding from '../screens/onboarding';
import AuthNavigation from './authNavigation';
import AppNavigation from './appNavigation';

const Stack = createStackNavigator();

function App() {
    return (
        <NavigationContainer>
            <Stack.Navigator screenOptions={{ headerShown: false }}>
                <Stack.Screen name="Splash" component={Splash} />
                <Stack.Screen name="Onboarding" component={Onboarding} />
                <Stack.Screen name="Auth" component={AuthNavigation} />
                <Stack.Screen name="AppNavigation" component={AppNavigation} />
            </Stack.Navigator>
        </NavigationContainer>
    );
}

export default App;