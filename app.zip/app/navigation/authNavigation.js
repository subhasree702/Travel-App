import React from 'react'
import { createStackNavigator } from '@react-navigation/stack';
import Login from '../screens/auth/login';
import VerifyOtp from '../screens/auth/verifyOtp';
import BeginComponent from '../components/BeginComponents';
import HomeScreen from '../screens/app/home';
import Registration from '../screens/auth/registration';
import Categories from '../components/categories';
import MostVisited from '../components/mostVisited';
import Services from '../components/services';
import PlaceDetailsScreen from '../screens/placeDetails';
const Stack = createStackNavigator();

const AuthNavigation = () => {
    return (
        <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="Login" component={Login} />
            <Stack.Screen name="VerifyOtp" component={VerifyOtp} />
            <Stack.Screen name="Registration" component={Registration} />
            <Stack.Screen name="HomeScreen" component={HomeScreen} />
            <Stack.Screen name="BeginComponent" component={BeginComponent} />
            <Stack.Screen name="Categories" component={Categories} /> 
             <Stack.Screen name="MostVisited" component={MostVisited} />
             <Stack.Screen name="Services" component={Services} />
             <Stack.Screen name="PlaceDetailsScreen" component={PlaceDetailsScreen} />
        </Stack.Navigator>
    )
}

export default AuthNavigation;